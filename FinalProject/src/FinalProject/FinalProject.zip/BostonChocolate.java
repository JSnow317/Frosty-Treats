package FinalProject;


public class BostonChocolate extends FrostyTreats{
	
	public BostonChocolate() { 
		name = "Boston Style Chocolate Ice cream";
		cones = "Waffle cone";
		texture = "Hard serve";
 
	}
}



