package FinalProject;


public class BostonPistachio extends FrostyTreats{
	
	public BostonPistachio() { 
		name = "Boston exclusive Pistachio Ice cream";
		cones = "Waffle cone";
		texture = "Hard serve";
 
	}
}


