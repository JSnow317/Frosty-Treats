package FinalProject;


public class BostonStrawBerry extends FrostyTreats{
	
	public BostonStrawBerry() { 
		name = "Boston Style StrawBerry Ice cream";
		cones = "Waffle cone";
		texture = "Hard serve";
	}
}


