package FinalProject;


public class BostonVanilla extends FrostyTreats{
	
	
	public BostonVanilla() { 
		name = "Boston Style Vanilla Ice cream";
		cones = "Waffle cone";
		texture = "Hard serve";
 
	}
}



