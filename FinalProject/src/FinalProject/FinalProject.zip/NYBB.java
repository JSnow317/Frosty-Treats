package FinalProject;

public class NYBB extends FrostyTreats{

	public NYBB() { 
		name = "New York exclusive style Ice cream Blueberry Broadway";
		cones = "Sugar cone";
		texture = "Frozen yogurt";

	
}

}


