package FinalProject;

public class NYChocolate extends FrostyTreats{

		public NYChocolate() { 
			name = "New York style Chocolate Ice cream";
			cones = "Sugar cone";
			texture = "Frozen yogurt";
	
		
	}

}
