package FinalProject;

public class NYStrawBerry extends FrostyTreats{

	public NYStrawBerry() { 
		name = "New York style StrawBerry Ice cream";
		cones = "Sugar cone";
		texture = "Frozen yogurt";

	


}

}
