package FinalProject;

public class NYVanilla extends FrostyTreats{
	
	public NYVanilla() { 
		name = "New York style Vanilla Ice cream";
		cones = "Sugar cone";
		texture = "Frozen yogurt";

	}
}
