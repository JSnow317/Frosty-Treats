package FinalProject;

public class PhillyChocolate extends FrostyTreats{
	
	public PhillyChocolate(){
	name = "Philly style Chocolate Ice Cream";
	cones = "Wafer Cone";
	texture = "Soft serve";
	

}
}
