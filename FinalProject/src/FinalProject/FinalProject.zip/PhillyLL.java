package FinalProject;

public class PhillyLL extends FrostyTreats{
	
	public PhillyLL(){
	name = "Philly's exclusive Liberty Lime Ice Cream";
	cones = "Wafer Cone";
	texture = "Soft serve";
	

}
}


