package FinalProject;

public class PhillyStrawBerry extends FrostyTreats{
	public PhillyStrawBerry(){
	name = "Philly style Strawberry Ice Cream";
	cones = "Wafer Cone";
	texture = "Soft serve";
	

	}

}


