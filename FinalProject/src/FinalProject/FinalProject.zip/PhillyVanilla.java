package FinalProject;

public class PhillyVanilla extends FrostyTreats{
	
	public PhillyVanilla(){
	name = "Philly style Vanilla Ice Cream";
	cones = "Wafer Cone";
	texture = "Soft serve";
	
	}

}
