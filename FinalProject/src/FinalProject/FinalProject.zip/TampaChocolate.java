package FinalProject;

public class TampaChocolate extends FrostyTreats{
	
	public TampaChocolate() { 
		name = "Tampa style Chocolate Ice cream";
		cones = "cup";
		texture = "Shaved Ice";
 
	}
}