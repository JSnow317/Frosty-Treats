package FinalProject;

public class TampaStrawBerry extends FrostyTreats{
	
	public TampaStrawBerry() { 
		name = "Tampa style Strawberry Ice cream";
		cones = "cup";
		texture = "Shaved Ice";
 
	}
}