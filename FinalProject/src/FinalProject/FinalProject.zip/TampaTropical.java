package FinalProject;

public class TampaTropical extends FrostyTreats{
	
	public TampaTropical() { 
		name = "Tampa style tropical tangerine Ice cream";
		cones = "cup";
		texture = "Shaved Ice";
 
	}
}
