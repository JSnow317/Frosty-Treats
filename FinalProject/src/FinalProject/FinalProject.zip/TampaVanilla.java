package FinalProject;

public class TampaVanilla extends FrostyTreats{
	
	public TampaVanilla() { 
		name = "Tampa style Vanilla Ice cream";
		cones = "cup";
		texture = "Shaved Ice";
 
	}
}
